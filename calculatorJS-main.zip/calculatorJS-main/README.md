# calculatorJS
Калькулятор на языке JavaScript

## Благодарность автору ( ₽ ):
* __Сбербанк VISA:__ 4274 3200 3233 1582
* __Yandex:__ 410011260821995 - https://sobe.ru/na/itdoctor 
* __PayPal:__ https://paypal.me/itdoctorstudio 
* __Станьте спонсором Youtube канала:__ https://www.youtube.com/channel/UC2Ev-rDSHBov0ZMChesLfrg/join

## Я, Исмаил Усеинов:
* __YouTube канал ITDoctor:__ https://www.youtube.com/c/ITDoctor
* __ВК:__ https://vk.com/morphop 
* __Группа в ВК:__ https://vk.com/itdoctorstudio 
* __Instagram:__ https://instagram.com/ismail_asanovich/ 
* __Twitter:__ https://twitter.com/ITDoctor_morph 
* __Telegram:__ https://t.me/itdoctorstudio 
* __Facebook:__ https://www.facebook.com/drinei 
